package com.example.smsclock;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLIteOpenHelper extends SQLiteOpenHelper{
	private static final String DATABASE_TABLE ="mainTable";
	//INDEX
	public static final String KEY_ID ="_id";
	public static final String KEY_NAME= "name";
	public static final int NAME_COLUMN = 1;
	private static final String DATABASE_CREATE = "create table " + DATABASE_TABLE + " (" + KEY_ID +
				" integer primary key autoincrement, " + KEY_NAME +" TEXT, mensagem TEXT, telefone TEXT, data TEXT, hora TEXT);";
	
	public MySQLIteOpenHelper(Context context, String DATABASE_NAME, CursorFactory factory, int DATABASE_VERSION) {
		super(context, DATABASE_NAME, factory, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(DATABASE_CREATE);
		
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// Log the version upgrade.
		Log.w("TaskDBAdapter", "Upgrading from version " +
		oldVersion + " to " +
		newVersion +
		", which will destroy all old data");
		// Upgrade the existing database to conform to the new version. // Multiple previous versions can be handled by comparing
		// _oldVersion and _newVersion values.
		// The simplest case is to drop the old table and create a // new one.
		db.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
		// Create a new one.
		onCreate(db);
		
	}

}
