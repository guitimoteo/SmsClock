package com.example.smsclock;


import java.text.SimpleDateFormat;
import java.util.Date;
import org.junit.Test;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteException;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

public class MyDB {
private final static String DATABASE_NAME = "myDatabase.db",
							DATABASE_TABLE ="mainTable",
							KEY_ID ="_id",
							KEY_NAME= "name";

private static final int DATABASE_VERSION = 1;
public 	static final int NAME_COLUMN = 1;

private SQLiteDatabase db;
private static CursorFactory factory;
private MySQLIteOpenHelper myOpenHelper;
private String strdata;
private SimpleDateFormat format;
/**
 * Os tipos da coluna foram escritos conforme a vers�o de sql padr�o,
 * por�m o Sqlite tem afinidade com estes tipos. 
 */
private static final String DATABASE_CREATE = "create table " + DATABASE_TABLE + " (" + KEY_ID +
" integer primary key autoincrement, " + KEY_NAME +" text not null );";

/**
 * Cria ou utiliza o banco de dados myDatabase.db no diret�rio /data do android
 * Tamb�m cria as colunas mensagem, telefone, data e hora.
 */
public MyDB(Context context){
	try{
		
	myOpenHelper  = new MySQLIteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION);	
	db = myOpenHelper.getWritableDatabase();

	}catch(SQLiteException e){
		Toast.makeText(context, "Erro ao criar ou acessar o banco de dados", Toast.LENGTH_LONG)
					  .show();
		System.err.println(e.getMessage());
		System.err.println(e.getCause());
		Log.e("Banco de dados: ", e.getMessage());
	}
}
/**
 * Fecha o banco de dados
 */
@Test
public void myDbClose(){
	
	try {
		
		db.close();
	} catch (Exception e) {
		Log.d(DATABASE_NAME, "N�o fechou corretamente");
		e.printStackTrace();
	}
	
}

@SuppressWarnings("deprecation")
@Test
public void setMyDbSqlInsert(CharSequence mensagem, CharSequence telefone, DatePicker data, TimePicker hora){
	try {
		/* A string n�o est� corretamente formatada, o correto � usar a classe format
		 * 
		 */
	
		String tempo = (hora.getCurrentHour() + "/" + hora.getCurrentMinute()).toString();
		format = new SimpleDateFormat("dd/MM/yyyy");
		
		strdata = format.format(new Date(data.getYear(),data.getMonth(), data.getDayOfMonth()));
		db.execSQL("INSERT INTO " + DATABASE_TABLE +" (mensagem, telefone, data, hora) VALUES (" 
					+ "'" + mensagem + "','" + telefone + "','" + strdata + "','" + hora +"')");
		Log.e("Banco de dados:" + DATABASE_TABLE, " '" + mensagem + "','" + telefone + "','"
													   + data + "','" + tempo +" ");
	} catch (SQLException e) {
		Log.e("Banco de dados: ", e.getMessage());
		e.printStackTrace();
	}
}
/**
 * Envia o comando Select para o banco de dados e retorna um Cursor com os campos da tabela 
 * mainTable
 * @return Cursor da tabela mainTable do banco de dados
 */
public Cursor getMySelectTable(){
	
	return db.rawQuery("SELECT * FROM "+ DATABASE_TABLE, null);
}

}
