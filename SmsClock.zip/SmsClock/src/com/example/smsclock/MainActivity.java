package com.example.smsclock;

import java.util.Calendar;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


public class MainActivity extends Activity {

static TextView mensagem;
static TextView telefone;
static TimePicker hora;
static DatePicker data;
Button   envia;
Calendar calendar;
//AlarmSms alarmSms;
Context context;
MyDB myDb;

SmsManager smsManager = SmsManager.getDefault();
Intent intent;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mensagem = (TextView)this.findViewById(R.id.editText2);
        telefone = (TextView)this.findViewById(R.id.editText1);
        hora = (TimePicker)this.findViewById(R.id.timePicker1);
        data = (DatePicker)this.findViewById(R.id.datePicker1);
        envia = (Button)this.findViewById(R.id.button1);
        
        
        //alarmSms = new AlarmSms();
        intent = new Intent(Intent.ACTION_SENDTO);
        

if( (telefone.getText()!=null && mensagem.getText()!=null)
 && (telefone.getText()!="" && mensagem.getText()!="")){
        envia.setOnClickListener(new Programe());
}else{
	Toast.makeText(getApplicationContext(), "Preencha todos os campos", Toast.LENGTH_LONG).show();
}
        
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.-
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    /**
     * Programa a mensagem a ser enviada com a data e hora retiradas dos Views
     * e futuramente de um banco de dados.
     * .
     * @author Guilherme
     *
     */
    private class Programe implements OnClickListener {
		@Override
		public void onClick(View v) {
			
			try{
			myDb = new MyDB(getApplicationContext());
			myDb.setMyDbSqlInsert(mensagem.getText(), telefone.getText(), 
									data, hora);
			myDb.myDbClose();
			Intent serviceIntent = new Intent(getApplicationContext(), AlarmSms.class);
			getApplicationContext().startService(serviceIntent);
			Log.d("AlarmSms", "OnClick: Mensagem programada");
			
			//ReceptorBoot.configurarAlarme(getApplicationContext());
			}catch(Exception e){
				Toast.makeText(getApplicationContext(),
									"Error: " + e.getMessage(),
									Toast.LENGTH_LONG).show();								  
				
			}
			
		}
	}
}


