package com.example.smsclock;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.os.IBinder;
import android.os.Looper;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

/**
 * AlarmSms � uma classe que envia um sms 
 * programado em determinada data e hor�rio 
 * @author Guilherme Timoteo
 *
 */
public class AlarmSms extends Service{
	

private Calendar calendar = Calendar.getInstance();
SmsManager smsManager;
PendingIntent sentIntent;
String telefone,  mensagem;
Timer timer = new Timer();
AlarmManager alarmManager;
MyDB myDB;
Cursor cursor;
private Date when;
private SimpleDateFormat format;



@Override
public int onStartCommand(Intent intent, int flags, int startId) {
   super.onStartCommand(intent, flags, startId);
   handleCommand(intent);
  
    return START_STICKY;
}

/**
 * Uma handler que cont�m a tarefa a ser realizada.
 * @param intent
 */
private void handleCommand(Intent intent) {
	
	try {
	myDB = new MyDB(this.getApplicationContext());
	cursor = myDB.getMySelectTable();
	cursor.moveToFirst();
	format = new SimpleDateFormat("dd/MM/yyyy");
	when = format.parse(cursor.getString(cursor.getColumnIndex("data")) + " " + 
				 		cursor.getString(cursor.getColumnIndex("hora")));
	timer.schedule(new Tarefa1(), when);
	
	Log.d("Tarefa: ", "Inicializando a primeira tarefa");
	
	} catch (Exception e) {
		Toast.makeText(getBaseContext(),"AlamSms: "+ e.getCause().toString(), Toast.LENGTH_LONG).show();
		e.printStackTrace();
	}finally{
		myDB.myDbClose();
	}
	Toast.makeText(getApplicationContext(), "Mensagem programada", Toast.LENGTH_LONG).show();

}

/**
 * Configura a data e hor�rio em que o sms deve ser enviado.
 * @param date
 */
public void setConfig(Date date){
	
	try {
		timer.schedule(new Tarefa1(), date);
	} catch (Exception e) {
		Toast.makeText(getBaseContext(), e.getCause().toString(), Toast.LENGTH_LONG).show();
		e.printStackTrace();
	}
}

@Override
	public IBinder onBind(Intent intent) {

		return null;
		
	}
/**
 * A classe envia o sms para o telefone e a mensagem escrita.
 * Ap�s, informa ao usu�rio que a mensagem foi enviada.
 * @author Guilherme Tim�teo
 *
 */
private class Tarefa1 extends TimerTask {
	
	private Looper looper;

	@Override
	public void run() {
		try{
			/*
			 * Ao que tudo indica, tinha que utilizar o Loop.prepare()
			 * Melhor verificar depois no debug.
			 */
			Looper.prepare();
			Looper.loop();
			
				/**
				 * Retirando o ReceptorBoot por enquanto
				 * ReceptorBoot.configurarAlarme(activity.getApplicationContext());
				 */
				telefone = cursor.getString(cursor.getColumnIndex("telefone"));
				mensagem = cursor.getString(cursor.getColumnIndex("mensagem"));

			smsManager = SmsManager.getDefault();
			smsManager.sendTextMessage(telefone, 
					 					null, 
					 					mensagem, 
					 					null,
					 					null);
			
			Toast.makeText(getBaseContext(), "mensagem enviada ",
						   Toast.LENGTH_LONG).show();
			
			}catch(Exception e){
				Toast.makeText(getApplication(), e.getMessage(), Toast.LENGTH_LONG).show();
			}finally{
				looper.quit();
			}
			
	}
}

}
