package com.example.smsclock;

import java.util.TimerTask;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.telephony.SmsManager;
import android.widget.Toast;
/**
 * A classe envia o sms para o telefone e a mensagem escrita.
 * Ap�s, informa ao usu�rio que a mensagem foi enviada.
 * @author Guilherme Tim�teo
 *
 */
public class Tarefa extends TimerTask {
Activity activity;
SmsManager smsManager;
PendingIntent sentIntent;
String telefone = "11991132504";
String mensagem = "Teste mensagem";
private Context context;

	@Override
	public void run() {
		try{
			System.out.println(context.fileList());
			
			/**
			 * Retirando o ReceptorBoot por enquanto
			 * ReceptorBoot.configurarAlarme(activity.getApplicationContext());
			 */
			Intent intent = new Intent(Intent.ACTION_SEND);
			this.smsManager = SmsManager.getDefault();
			this.sentIntent = PendingIntent.getService(context , 0, intent, PendingIntent.FLAG_ONE_SHOT);
			


			smsManager.sendTextMessage(telefone.toString(), 
					 					null, 
					 					mensagem.toString(), 
					 					sentIntent, 
					 					null);
			
			Toast.makeText(context, "mensagem enviada ",
						   Toast.LENGTH_LONG).show();
			
			}catch(Exception e){
				Toast.makeText(activity.getApplication(), e.getMessage(), Toast.LENGTH_LONG).show();
			}
		
	}

}
